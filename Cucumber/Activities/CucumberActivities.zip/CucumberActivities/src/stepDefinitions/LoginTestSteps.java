package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginTestSteps {
	
	WebDriver driver;
	WebDriverWait wait;
	
	@Given("^User is on Login page$")
	public void setUp() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, 10);
		driver.get("https://www.training-support.net/selenium/login-form");
	}
	
	@When("^User enters username and password$")
	public void testLogin() {
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("password");
		driver.findElement(By.xpath("//button[contains(text(),'Log in')]")).click();
	}
	
	@When("^User enter \"(.*)\" and \"(.*)\"$")
	public void parametrizedLogin(String username,String password) throws Throwable {
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);
		driver.findElement(By.xpath("//button[contains(text(),'Log in')]")).click();
	}
	
	@SuppressWarnings("deprecation")
	@Then("^Read the page title and confirmation message$")
	public void readPageTitleAndConfirmationMessage() {
		String title = driver.getTitle();
		String loginMessage = driver.findElement(By.xpath("//div[@id='action-confirmation']")).getText();
		System.out.println("Page title: " + title);
		System.out.println("Confirmation message: " + loginMessage);
		if(loginMessage.contains("Admin")) 
			Assert.assertEquals(loginMessage, "Welcome Back, admin");
		else 
			Assert.assertEquals(loginMessage, "Invalid Credentials");
	}
	
	/*@And("^Close the browser$")
	public void close() {
		driver.close();
	}*/
	
}
