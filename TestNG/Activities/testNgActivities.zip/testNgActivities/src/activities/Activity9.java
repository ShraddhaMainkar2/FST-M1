package activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Activity9 {
	
	WebDriver driver;
	
	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		driver = new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/javascript-alerts");
	}
	
	@BeforeMethod
	public void beforeMethod() {
		driver.switchTo().defaultContent();
	}
	
	@Test
	public void simpleAlertTestCase() {
		driver.findElement(By.xpath("//button[@id='simple']")).click();
		Reporter.log("Clicking first button");
		Alert alert = driver.switchTo().alert();
		Reporter.log("Simple Alert view");
		String simpleAlertText = alert.getText();
		System.out.println("Alert text: " + simpleAlertText);
		Assert.assertEquals(simpleAlertText, "This is a JavaScript Alert!");
		alert.accept();
		Reporter.log("Clicked on OK button");
	}
	
	@Test
	public void confirmAlertTestCase() {
		driver.findElement(By.xpath("//button[@id='confirm']")).click();
		Reporter.log("Clicking second button");
		Alert alert = driver.switchTo().alert();
		Reporter.log("Confirmation Alert view");
		String confirmAlertText = alert.getText();
		System.out.println("Alert text: " + confirmAlertText);
		Assert.assertEquals(confirmAlertText, "This is a JavaScript Confirmation!");
		alert.dismiss();
		Reporter.log("Clicked on Cancel button");
	}
	
	@Test
	public void promptAlertTestCase() {
		driver.findElement(By.xpath("//button[@id='prompt']")).click();
		Reporter.log("Clicking third button");
		Alert alert = driver.switchTo().alert();
		Reporter.log("Prompt Alert view");
		String promptAlertText = alert.getText();
		System.out.println("Alert text: " + promptAlertText);
		Assert.assertEquals(promptAlertText, "This is a JavaScript Prompt!");
		alert.sendKeys("Hi");
		Reporter.log("Sent test data");
		alert.accept();
		Reporter.log("Clicked on OK button");
	}
	
	@AfterClass(alwaysRun = true)
	public void afterClass() {
		driver.close();
	}

}
