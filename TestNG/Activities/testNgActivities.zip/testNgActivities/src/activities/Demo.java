package activities;

import org.testng.annotations.Test;

public class Demo {
	
	@Test
	public void test() {
		System.out.println("Test");
	}
	
}
