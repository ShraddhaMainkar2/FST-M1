//Grouping in testng

package activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Activity5 {
  
	WebDriver driver;
	
	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		driver = new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
	}
	
	@Test(groups = {"HeaderTests, ButtonTests"})
	public void checkPageTitle() {
		String pageTitle = driver.getTitle();
		System.out.println("Page title: " + pageTitle);
		Assert.assertEquals(pageTitle, "Target Practice");
	}
	
	@Test(dependsOnMethods = {"checkPageTitle"}, groups = {"HeaderTests"})
	public void checkHeading() {
		String heading = driver.findElement(By.xpath("//h3[@id='third-header']")).getText();
		System.out.println("Page title: " + heading);
		Assert.assertEquals(heading, "Third header");
	}
	
	@Test(dependsOnMethods = {"checkPageTitle"}, groups = {"HeaderTests"})
	public void findHeadingColor() {
		String headingColor = driver.findElement(By.xpath("//h5[starts-with(@class,'ui green')]")).getCssValue("color");
		System.out.println("Fith heading color: " + headingColor);
		Assert.assertEquals(headingColor, "rgb(33, 186, 69)");
	}
	
	@Test(dependsOnMethods = {"checkPageTitle"}, groups = {"ButtonTests"})
	public void findButton() {
		String buttonText = driver.findElement(By.xpath("//button[starts-with(@class,'ui olive')]")).getText();
		System.out.println("Button text: " + buttonText);
		Assert.assertEquals(buttonText, "Olive");
	}
	
	@Test(dependsOnMethods = {"checkPageTitle"}, groups = {"ButtonTests"})
	public void findButtonColor() {
		String buttonColor = driver.findElement(By.xpath("//button[starts-with(@class,'ui brown')]")).getCssValue("color");
		System.out.println("Button color: " + buttonColor);
		Assert.assertEquals(buttonColor, "rgb(255, 255, 255)");
	}
	
	
	
	@AfterClass(alwaysRun = true)
	public void afterClass() {
		driver.close();
	}

}
