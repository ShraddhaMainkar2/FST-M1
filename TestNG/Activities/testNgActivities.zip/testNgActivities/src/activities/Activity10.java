package activities;

import org.testng.annotations.Test;	
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Activity10 {
	
	WebDriver driver;
	Actions slider;
	
	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		driver = new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/sliders");
		slider = new Actions(driver);
	}
  
	@Test
	public void testMiddleValueOfSlider() {
		driver.findElement(By.xpath("//input[@id='slider']")).click();
		Reporter.log("Slider clicked");
		String volume = driver.findElement(By.xpath("//span[@id='value']")).getText();
		Assert.assertEquals(volume, "50");
	}
	
	@Test
	public void moveSliderToRightEnd() {
		WebElement slide = driver.findElement(By.xpath("//input[@id='slider']"));
		slider.clickAndHold(slide).moveByOffset(75, 0).release().build().perform();
		Reporter.log("Slider moved to right end");
		String volume = driver.findElement(By.xpath("//span[@id='value']")).getText();
		Assert.assertEquals(volume, "100");
	}
	
	@Test
	public void moveSliderToLeftEnd() {
		WebElement slide = driver.findElement(By.xpath("//input[@id='slider']"));
		slider.clickAndHold(slide).moveByOffset(-75, 0).release().build().perform();
		Reporter.log("Slider moved to left end");
		String volume = driver.findElement(By.xpath("//span[@id='value']")).getText();
		Assert.assertEquals(volume, "0");
	}
	
	@Test
	public void moveSliderTo30percent() {
		WebElement slide = driver.findElement(By.xpath("//input[@id='slider']"));
		slider.clickAndHold(slide).moveByOffset(-30, 0).release().build().perform();
		Reporter.log("Slider moved to 30 percent");
		String volume = driver.findElement(By.xpath("//span[@id='value']")).getText();
		Assert.assertEquals(volume, "30");
	}
	
	@Test
	public void moveSliderTo80percent() {
		WebElement slide = driver.findElement(By.xpath("//input[@id='slider']"));
		slider.clickAndHold(slide).moveByOffset(45, 0).release().build().perform();
		Reporter.log("Slider moved to 80 percent");
		String volume = driver.findElement(By.xpath("//span[@id='value']")).getText();
		Assert.assertEquals(volume, "80");
	}
  
	@AfterClass(alwaysRun = true)
	public void afterClass() {
		driver.close();
	}

}
