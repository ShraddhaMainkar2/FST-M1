package activities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;

public class Activity2 {

	WebDriver driver;
  
	@BeforeClass
	public void beforeClass() {
		driver = new FirefoxDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
	}
  
	//Test 1
	@Test
	public void getTitle() {
		String title = driver.getTitle();
		System.out.println("Page Title: " + title);
		Assert.assertEquals(title, "Target Practice");
	}
	
	//Test 2
	@Test
	public void locateButton() {
		String buttonText = driver.findElement(By.xpath("//button[starts-with(@class,'ui black')]")).getText();
		System.out.println("Page Title: " + buttonText);
		Assert.assertEquals(buttonText, "White");
	}
	
	//Test 3
	@Test(enabled = false)
	public void skipMethod() {
		System.out.println("Method to be skipped");
	}
	
	//Test 4
	@Test
	public void skipMethodByException() {
		throw new SkipException("Skipped");
	}
	
  
	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
