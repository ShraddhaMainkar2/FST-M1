package suiteExample;

import org.testng.annotations.Test;

public class Activity4_DemoTwo {
	
	@Test
	public void testCase() {
		
		System.out.println("I'm in the test case from Activity4_DemoTwo class");
		
	}
  
}
