package suiteExample;

import org.testng.annotations.Test;

public class Activity4_DemoOne {
	
	@Test
	public void testCase1() {
		
		System.out.println("I'm the first test case from Activity4_DemoOne class");
		
	}
  
	@Test
	public void testCase2() {
	
		System.out.println("I'm the second test case from Activity4_DemoOne class");
	
	}
  
}
